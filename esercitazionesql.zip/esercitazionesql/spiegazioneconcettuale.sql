/*ToysGroup è un’azienda che distribuisce articoli (giocatoli) in diverse aree geografiche del mondo. I prodotti 
sono classificati in categorie e i mercati di riferimento dell’azienda sono classificati in regioni di vendita. 
In particolare: Le entità individuabili in questo scenario sono le seguenti: 
❏ - Product 
❏ - Region 
❏ - Sales 
Le relazioni tra le entità possono essere descritte nel modo seguente: 
❏ Product e Sales
❏ Un prodotto può essere venduto tante volte (o nessuna) per cui è contenuto in una o più transazioni 
di vendita. 
❏ Ciascuna transazione di vendita è riferita ad uno solo prodotto 

❏ Region e Sales
❏ Possono esserci molte o nessuna transazione per ciascuna regione 
❏ Ciascuna transazione di vendita è riferita ad una sola regione 
Fornisci schema concettuale e schema logico*/

/* schema: venditeToysgroup
tabelle :  CREATE TABLE :
Product AS prodotto:
-Idprodotto INT PrimaryKey AI NOT NULL
-nomeprodotto VARCHAR (20) NOT NULL
-categoriaprodotto VARCHAR (20) NOT NULL
-prezzoprodotto DECIMAL (6,2) NOT NULL

Region AS Areageografica
-Idareageografica INT PrimaryKey AI NOT NULL
-nomeareageografica VARCHAR (12) NOT NULL

Sales AS vendita
-idvendita INT PrimaryKey AI NOT NULL
-idprodotto INT FK NOT NULL
-idareageografica INT FK NOT NULL
-categoriaprodotto VARCHAR (20) NOT NULL
-datavendita DATE NOT NULL
-prezzoprodotto DECIMAL (6,2) NOT NULL 
-quantitaprodotto INT NOT NULL
-prezzoprodotto*quantitaprodotto AS totale DECIMAL (6,2) NOT NULL 
