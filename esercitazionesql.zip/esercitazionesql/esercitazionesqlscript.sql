CREATE SCHEMA venditeToysgroup;

USE venditeToysgroup;

/*questa prima query creata tramite codice*/
CREATE TABLE vendite (
idvendita INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
idprodotto INT NOT NULL,
idareageografica INT NOT NULL,
categoriaprodotto VARCHAR (20) NOT NULL,
datavendita DATE NOT NULL,
prezzoprodotto DECIMAL (6,2) NOT NULL, 
quantitaprodotto INT NOT NULL,
totale DECIMAL (6,2) NOT NULL); 

/* queste due tramite workbench*/
CREATE TABLE `venditetoysgroup`.`areageografica` (
  `idareageografica` INT NOT NULL AUTO_INCREMENT,
  `nomeareageografica` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`idareageografica`));
  
  CREATE TABLE `venditetoysgroup`.`prodotto` (
  `idprodotto` INT NOT NULL AUTO_INCREMENT,
  `nomeprodotto` VARCHAR(20) NOT NULL,
  `categoriaprodotto` VARCHAR(20) NOT NULL,
  `prezzoprodotto` DECIMAL(6,2) NOT NULL,
  PRIMARY KEY (`idprodotto`));
   
/*inserite idprodotto e idareageografica come FK della tabella vendite*/
ALTER TABLE `venditetoysgroup`.`vendite` 
ADD INDEX `idareageografica_idx` (`idareageografica` ASC) VISIBLE;
ALTER TABLE `venditetoysgroup`.`vendite` 
ADD CONSTRAINT `idareageografica`
  FOREIGN KEY (`idareageografica`)
  REFERENCES `venditetoysgroup`.`areageografica` (`idareageografica`)
  ON DELETE CASCADE
  ON UPDATE CASCADE;
  
/*Crea e popola le tabelle utilizzando dati a tua discrezione 
(sono sufficienti pochi record per tabella; riporta le query utilizzate).*/ 
/*i dati utilizzati sono stati creati e tabellati tramite excel 
(power query per calcolare la colonna totale snella tabella 'vendite') e gemini ai*/

INSERT INTO venditeToysgroup.prodotto (nomeprodotto, categoriaprodotto, prezzoprodotto) VALUES
('Cicciobello', 'bambolo', 77.60 ),
('Cicciobrutto', 'bambolo', 39.99), 
('Risiko!', 'giocodatavolo', 45.99),
('Rosiko?', 'giocodatavolo', 45.99), 
('Gormiti', 'actionfigure',	29.90), 
('Bicigrande', 'bikes',	466.99),
('Bicipiccola', 'bikes', 229.88),
('Barbieterrona', 'bambola',38.90), 
('Barbiecoatta', 'bambola',	49.99 ),
('Barbiemilanese', 'bambola', 120.99);

INSERT INTO venditeToysgroup.areageografica (nomeareageografica) VALUES
('europa'),
('africa'),
('asia'),
('nordamerica'),
('sudamerica'),
('oceania');

INSERT INTO venditeToysgroup.vendite (idprodotto, idareageografica, categoriaprodotto, 
datavendita, prezzoprodotto, quantitaprodotto, totale) VALUES
(1,	1, 'bambolo', '2022-01-13',	'77.6',	1, '77.6'),
(2, 1, 'bambolo', '2023-07-14', 39.99, 2, 79.98),
(3,	4, 'giocodatavolo', '2024-12-10', 45.99, 1, 45.99),
(4,	4, 'giocodatavolo',	'2023-12-18', 45.99, 1,	45.99),
(5,	1, 'actionfigure',	'2022-08-03', 29.90, 1, 29.90),
(6,	6, 'bikes',	'2023-06-19', 466.99, 1, 466.99),
(7,	3, 'bikes',	'2023-11-09', 229.88, 2, 459.76),
(9,	2,	'bambola',	'2024-12-06', 49.99, 3,	149.97),
(9,	5,	'bambola',	'2022-10-02',	49.99,	2,	99.98),
(10, 4,	'bambola',	'2022-05-05',	120.99,	1,	120.99),
(1,	2,	'bambolo',	'2022-04-08',	77.60,	1,	77.60),
(2,	5,	'bambolo',	'2023-01-21',	39.99,	2,	79.98),
(3,	1,	'giocodatavolo', '2023-09-04',	45.99,	1,	45.99),
(4,	5,	'giocodatavolo', '2023-04-06',	45.99,	1,	45.99),
(5,	4,	'actionfigure',	'2023-10-09', 29.90, 3,	89.70),
(6,	3,	'bikes', '2023-05-12', 466.99, 1, 466.99),
(7,	3,	'bikes', '2024-04-12', 229.88, 1, 229.88),
(5,	4,	'actionfigure',	'2024-02-05', 29.90, 3,	89.70),
(9,	5,	'bambola', '2024-03-18', 49.99, 2, 99.98),
(10, 1,	'bambola', '2024-11-19', 120.99, 2,	241.98);

/*Dopo la creazione e l’inserimento dei dati nelle tabelle, esegui e riporta delle query utili a:
Verificare che i campi definiti come PK siano univoci.*?
/*La query scritta confronta  tramite la funzione count il valore PK, con e senza funzione distinct,
se le righe ottenute sono uguali per entrambe le colonne allore il valore e' PK*/ 

/*verifica pk tabella area geografica*/
SELECT 
    COUNT(areageografica.idareageografica) AS NumeroRighe,
    COUNT(DISTINCT areageografica.idareageografica) AS NumeroRigheSenzaRipetizioni
FROM
    areageografica;
    
/* verifica pk prodotto*/
SELECT 
    COUNT(prodotto.idprodotto) AS NumeroRighe,
    COUNT(DISTINCT prodotto.idprodotto) AS NumeroRigheSenzaRipetizioni
FROM
    prodotto;
    
/* verifica pk vendite*/
SELECT 
    COUNT(vendite.idvendita) AS NumeroRighe,
    COUNT(DISTINCT vendite.idvendita) AS NumeroRigheSenzaRipetizioni
FROM
    vendite;

/*Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.*/
/*Provato con e senza distinct ottenendo lo stesso risultato*/
SELECT nomeprodotto, SUM(totale) AS Fatturatotale, YEAR(datavendita) AS anno
FROM vendite A
JOIN prodotto B ON A.idprodotto = B.idprodotto
GROUP BY YEAR(datavendita), nomeprodotto;

/*Esporre il fatturato totale per stato per anno. 
Ordina il risultato per data e per fatturato decrescente.*/
SELECT nomeareageografica, SUM(totale) AS Fatturatotale, YEAR(datavendita) AS anno
FROM vendite A
JOIN prodotto B ON A.idprodotto = B.idprodotto
JOIN areageografica C ON A.idareageografica = C.idareageografica
GROUP BY YEAR (datavendita), nomeareageografica
ORDER BY YEAR (datavendita) DESC, SUM(totale) DESC;
  
/*Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?*/
/*Considerando la categoria e la quantita'*/  
/*mostrando solo la categoria prodotto*/
SELECT categoriaprodotto
FROM (SELECT categoriaprodotto, COUNT(categoriaprodotto) AS countcategoria 
FROM vendite 
GROUP BY categoriaprodotto) AS concat
GROUP BY categoriaprodotto
ORDER BY countcategoria DESC
LIMIT 1;

/*Considerando la categoria e la quantita'*/  
/*mostrando la categoria prodotto e quanto unita' sono state vendute*/
SELECT categoriaprodotto, MAX(countcategoria) AS catmaggrichiesta
FROM (SELECT categoriaprodotto, COUNT(categoriaprodotto) AS countcategoria 
FROM vendite 
GROUP BY categoriaprodotto) AS concat
GROUP BY categoriaprodotto
ORDER BY catmaggrichiesta DESC
LIMIT 1;

/*considerando la categoria legata alla categoriaprodotto che ha fatturato di piu' */
/**mostrando solo la categoria prodotto per cui si ha maggiore fatturato*/
SELECT categoriaprodotto
FROM(
SELECT categoriaprodotto, SUM(totale) AS fatturatoprodotto
FROM vendite 
GROUP BY categoriaprodotto) AS fatprod
GROUP BY categoriaprodotto
ORDER BY fatturatoprodotto DESC
LIMIT 1;

/*considerando la categoria legata alla categoriaprodotto che ha fatturato di piu' */
/*mostrando la categoria prodotto e quanto e' il maxfatturatoprodotto*/
SELECT categoriaprodotto, MAX(fatturatoprodotto) AS maxfatturatoprodotto
FROM(
SELECT categoriaprodotto, SUM(totale) AS fatturatoprodotto
FROM vendite 
GROUP BY categoriaprodotto) AS fatprod
GROUP BY categoriaprodotto
ORDER BY maxfatturatoprodotto DESC
LIMIT 1;

/*Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? 
Proponi due approcci risolutivi differenti.*/
/*METODO 1 */
/*uso query con NOT IN e basandomi sull'assenza dell' id prodotto dalla tabella 'Vendite', 
che ci dice che non sono state effettuate vendite di quel prodotto */
/*mostrando solo il prodotto*/
SELECT A.nomeprodotto
FROM prodotto A
WHERE A.idprodotto NOT IN
(SELECT B.idprodotto
FROM prodotto A
JOIN vendite B ON A.idprodotto = B.idprodotto);

/*METODO 1.1*/
/*mostrando prodotto e relativo id*/
SELECT A.nomeprodotto, A.idprodotto
FROM prodotto A
WHERE A.idprodotto NOT IN
(SELECT B.idprodotto
FROM prodotto A
JOIN vendite B ON A.idprodotto = B.idprodotto);

/*METODO 2*/
/* qui uso una query con IFNULL e basandomi sull'assenza del valore 'datavenditarecente' 
per il relativo campo prodotto*/
SELECT nomeprodotto
FROM (
SELECT A.nomeprodotto,IFNULL (datavendita, 'NA') AS datavenditarecente
FROM prodotto A
LEFT JOIN vendite B ON A.idprodotto = B.idprodotto 
GROUP BY A.nomeprodotto, B.datavendita) AS proddat
WHERE datavenditarecente = 'NA';

/*Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).*/
SELECT nomeprodotto, MAX(datavendita) AS datavenditarecente
FROM 
(SELECT nomeprodotto, datavendita
FROM prodotto A
LEFT JOIN vendite B ON A.idprodotto = B.idprodotto 
GROUP BY nomeprodotto, datavendita) AS proddat
GROUP BY nomeprodotto;

  

